from .ingress_api import IntelMap as IntelMap
